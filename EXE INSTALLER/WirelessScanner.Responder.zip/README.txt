WirelessScanner responder 1.5.0 (DR-0014 stage C)

Run on a WIRED machine with the .NET 10 runtime:
  dotnet WirelessScanner.Responder.dll [--port 5410] [--name "Lab Pi"]
First run prints the pairing key (later: --show-key). Pair it in WirelessScanner: SETTINGS -> Test servers.
Allow TCP and UDP 5410 for the local network only. Only authenticated traffic is answered.
